# Name: Debasish Kanhar
# Emp ID: 05222V

from ..core.schema.PropertyKeyBuilder import PropertyKeyBuilder
from ..core.schema.VertexLabelBuilder import VertexLabelBuilder
from ..core.schema.EdgeLabelBuilder import EdgeLabelBuilder
from ..core.schema.IndexBuilder import IndexBuilder
from ..core.schema.index.AwaitGraphIndex import AwaitGraphIndex
from ..core.schema.index.UpdateIndex import UpdateIndex
from ..core.schema.ManagementExecutors import ManagementExecutors

from gremlin_python.driver.client import Client


class JanusGraphManagement(object):
    def __init__(self, connection, printSchema=False):
        """

        Args:
            connection (Client):
        """

        self.connection = connection
        self.executor = ManagementExecutors(connection, printSchema)
        self.printSchema = printSchema
        pass

    def propertyKeyBuilder(self):
        builder = PropertyKeyBuilder(self.connection, self.printSchema)
        return builder

    def vertexLabelBuilder(self):
        builder = VertexLabelBuilder(self.connection, self.printSchema)
        return builder

    def edgeLabelBuilder(self):
        builder = EdgeLabelBuilder(self.connection, self.printSchema)
        return builder

    def buildVertexCentricIndex(self, index_name):
        builder = IndexBuilder(self.connection, self.printSchema).buildVertexCentricIndex(index_name)
        return builder

    def buildCompositeIndex(self, index_name, element):
        builder = IndexBuilder(self.connection, self.printSchema).buildCompositeIndex(index_name, element)
        return builder

    def buildMixedIndex(self, index_name, element):
        builder = IndexBuilder(self.connection, self.printSchema).buildMixedIndex(index_name, element)
        return builder

    def awaitGraphIndexStatus(self, index_name):
        builder = AwaitGraphIndex(self.connection, index_name, self.printSchema)
        return builder

    def updateIndex(self, index_name):
        builder = UpdateIndex(self.connection, index_name, self.printSchema)
        return builder

    def getOpenInstances(self):
        instances = self.executor.getOpenInstances()
        return instances

    def forceCloseInstance(self, instance_id):
        self.executor.forceCloseInstance(instance_id)

    def commit(self):
        self.executor.commit()
